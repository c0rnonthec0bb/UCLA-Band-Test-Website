

<div align="center">
    <table id="home-sliders" class="card" style="width:80vw;" align="center">
        <tr>
            <td class="spacer"></td>
            <td align="center">
                <div class="slider">
                    <?php echo do_shortcode("[R-slider id='1']"); ?>
                </div>
            </td>
            <td align="center">
                <div class="slider" style="margin-left: 1vmin;">
                    <?php echo do_shortcode("[R-slider id='3']");?>
                </div>
            </td>
            <td class="spacer"></td>
        </tr>
    </table>
</div>
